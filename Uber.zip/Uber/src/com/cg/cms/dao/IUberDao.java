package com.cg.cms.dao;

import java.util.Map;

import com.cg.cms.bean.Cab;
import com.cg.cms.exceptions.UberException;

public interface IUberDao 
{
	public Cab getUberBook(Cab cab) throws UberException;
	
	public Cab getUberDetails() throws UberException;

	public void setUberDetails(Cab cab);

	public Cab getCabDetails(int cabId);

	public Map<Integer, Cab> getAllBookingDetails();

}
