package com.cg.cms.ui;

import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

import com.cg.cms.bean.Cab;
import com.cg.cms.exceptions.UberException;
import com.cg.cms.service.IUberService;
import com.cg.cms.service.UberService;

public class Client 
{
	public static void main(String[] args) 
	{

		IUberService service = new UberService();
		Scanner scanner = null;
		Cab cab;

		String continueChoice="";
		boolean continueFlag = false;

		do 
		{
			System.out.println("*******Welcome to Uber App*******");
			System.out.println("1) Book a Cab");
			System.out.println("2) Get all details of customer");
			System.out.println("3) Exit");

			int choice=0;
			boolean choiceFlag=false;
			do 
			{
				scanner=new Scanner(System.in);
				System.out.println("Enter your choice :");

				try 
				{
					choice=scanner.nextInt();
					choiceFlag=true;
					
					switch(choice)
					{
					case 1:
						cab= new Cab();
						String name="";
						boolean nameFlag=false;
						do {
							
							System.out.println("Enter your name :");
							scanner =new Scanner(System.in);
							try 
							{
								name=scanner.nextLine();
								service.validateName(name);
								cab.setName(name);
								nameFlag=true;
							} catch (UberException e) 
							{
								nameFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!nameFlag);
						
						String mobile="";
						boolean mobileFlag=false;
						do {
							
							System.out.println("Enter your mobile no. :");
							scanner =new Scanner(System.in);
							try 
							{
								mobile=scanner.nextLine();
								service.validateMobile(mobile);
								cab.setMobile(mobile);
								mobileFlag=true;
							} catch (UberException e) 
							{
								mobileFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!mobileFlag);
						
						String pickUp="";
						boolean pickUpFlag=false;
						do {
							
							System.out.println("Enter your pickUp location :");
							scanner =new Scanner(System.in);
							try 
							{
								pickUp=scanner.nextLine();
								service.validatePickUp(pickUp);
								cab.setPickUp(pickUp);
								pickUpFlag=true;
							} catch (UberException e) 
							{
								pickUpFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!pickUpFlag);
						
						String drop="";
						boolean dropFlag=false;
						do {
							
							System.out.println("Enter your drop location :");
							scanner =new Scanner(System.in);
							try 
							{
								drop=scanner.nextLine();
								service.validateDrop(drop);
								cab.setDrop(drop);
								dropFlag=true;
							} catch (UberException e) 
							{
								dropFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!dropFlag);
						
					
						System.out.println("Your cab booked successfully!!!");
						int otp=(int)(Math.random()*100);
						int cabId=(int)(Math.random()*100);
						cab.setCabId(cabId);
						service.setUberDetails(cab);
						System.out.println("Your OTP is "+ otp +"CAB ID is: "+cabId);
						
						break;
						
					case 2:
						System.out.print("Enter Your ID: ");
						cabId=scanner.nextInt();
						cab=service.getCabDetails(cabId);
						
							System.out.println(cab);
						
							//System.out.println("Incorrect cab Id.");
						
						
						break;
						
					case 3:
						
						Map<Integer,Cab> map=service.getAllBookingDetails();
						System.out.println("KeySet: ");
						for(Integer i:map.keySet())
							System.out.println(i);
						
						
						System.out.println("Values: ");
						for(Cab c:map.values())
							System.out.println(c);
						
						
						System.out.println("Entry SEt: ");
						for(Object o:map.entrySet())
							System.out.println(o);
						
						
						System.out.println("Entry SEt: ");
						for(Map.Entry o:map.entrySet()) {
							System.out.print("Key");
							System.out.print(o.getValue());
							System.out.print("\t Value");
							System.out.println(o.getKey());
							
						}
							
						
						
						
						
						System.out.println("Thank You");
						System.exit(0);
						
					default :
						
						System.out.println("Enter digits only");
						break;
					}
				}
				catch (InputMismatchException e) 
				{
					System.out.println("Enter digits only 1,2 or 3");
				}



			}while(!choiceFlag);
			scanner = new Scanner(System.in);
			System.out.println("Do want to continue [Yes/No]");
			continueChoice=scanner.next();

		}while(continueChoice.equalsIgnoreCase("Yes"));
	}

}
