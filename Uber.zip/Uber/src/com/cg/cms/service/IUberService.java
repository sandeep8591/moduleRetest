package com.cg.cms.service;

import java.util.Map;

import com.cg.cms.bean.Cab;
import com.cg.cms.exceptions.UberException;

public interface IUberService 
{
	public Cab getUberBook(Cab cab) throws UberException;
	
	public Cab getUberDetails() throws UberException;
	
	
	
	public void setUberDetails(Cab cab) ;
	
	public Cab getCabDetails(int cabId);
	
	public Map<Integer,Cab> getAllBookingDetails();

	public void validateName(String name) throws UberException;

	public void validateMobile(String mobile) throws UberException;

	public void validatePickUp(String pickUp) throws UberException;

	public void validateDrop(String drop) throws UberException;

}
