package com.cg.tms.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.tms.dto.TicketBean;

public class Util {
	
	private static Map<String,String> ticketCategory=new HashMap<String,String>();
	private static Map<String,TicketBean> ticketLog=new HashMap<String,TicketBean>();
	
	public Map<String,String> getTicketCategory(){
		ticketCategory.put("tc001", "software installation");
		ticketCategory.put("tc002", "mailbox creation");
		ticketCategory.put("tc003", "mailbox issues");
		
		return ticketCategory; 
		
	
	}
	public void storeTicketdetail(TicketBean ticket){
		
		ticketLog.put(ticket.getTicketNo(), ticket);
		
	}
	

}
