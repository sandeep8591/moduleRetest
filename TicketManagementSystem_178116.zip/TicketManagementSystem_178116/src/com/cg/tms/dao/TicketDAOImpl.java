package com.cg.tms.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.util.Util;

public class TicketDAOImpl implements TicketDAO {
	Map<String,String> m1=null;
	Util db=new Util();
	@Override
	public boolean raiseNewTicket(TicketBean ticketbean) {
	
		db.storeTicketdetail(ticketbean);
		
		
		return true;
	}

	@Override
	public List<TicketCategory> listTicketCategory() {
		
		m1=db.getTicketCategory();
		List<TicketCategory> listdetail=new ArrayList(m1.values());
			return listdetail;
	}

}
