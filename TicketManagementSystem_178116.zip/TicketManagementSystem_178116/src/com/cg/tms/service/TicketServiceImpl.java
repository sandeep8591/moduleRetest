package com.cg.tms.service;

import java.util.List;

import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public class TicketServiceImpl implements TicketService {

	TicketDAOImpl dao=new TicketDAOImpl();
	
	
	@Override
	public boolean raiseNewTicket(TicketBean ticketbean) {
		dao.raiseNewTicket(ticketbean);
		return true;
	}


	@Override
	public List<TicketCategory> listTicketCategory() {
		
		return dao.listTicketCategory();
	}

	
	/*public void listTicketcategory() {
		System.out.println("Select Ticket Category from below list:");
		System.out.println("1.Software Installation");
		System.out.println("2.Mailbox Creation");
		System.out.println("3.network issue");
		
	}*/

}
