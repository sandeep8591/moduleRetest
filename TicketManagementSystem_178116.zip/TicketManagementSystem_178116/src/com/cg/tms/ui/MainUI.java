package com.cg.tms.ui;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.service.TicketServiceImpl;


public class MainUI {
	
	public static void main(String[] args) {
		
		Scanner scn=new Scanner(System.in);
		Scanner scn1=new Scanner(System.in);
	
		TicketBean t1=new TicketBean();
		TicketServiceImpl serimp=new TicketServiceImpl();
		
		Date d1=new Date();
		
		int opt;
		
		System.out.println("***************WELCOME TO ITIMD HELP DESK********************");
		System.out.println();
		do {
			System.out.println("Choose the option to serve better:");
			System.out.println("1.Raise a Ticket");
			System.out.println("2.Exit from system");
			opt=scn.nextInt();
		
			if(opt==1) {
				System.out.println("Select Ticket Category from below List:");
				
				//listing ticket category 
				
				List<TicketCategory> tc=serimp.listTicketCategory();
				System.out.println("1."+tc.get(0));
				System.out.println("2."+tc.get(1));
				System.out.println("3."+tc.get(2));
				String cat=scn.nextLine();
				
				System.out.println();
				
				System.out.print("Eneter option:");
				int catopt=scn.nextInt();
				System.out.println("Enter description related to issue:");
				String disc=scn1.nextLine();
				System.out.print("Enter Priority(1.low 2.medium 3.high) :");
				int tcpriority=scn.nextInt();
				
				//generating random ticket number
				
				int ticketNumber = (int )(Math. random() * 1000 + 1);
				System.out.println();
	
				System.out.println("Ticket Number "+ticketNumber+" logged successfully at " +d1);
				System.out.println();
				
				//inserting accepted detail into Ticket Map
				
				t1.setTicketStatus("new");
				t1.setTicketDescription(disc);
				t1.setTicketCategoryId(cat);
				
				//validation ticket bean database
				
				boolean b1=serimp.raiseNewTicket(t1);
				if(b1==true) {
					System.out.println("will contact soon");
				}
				
				System.out.println();
				System.out.println();
		
			}
			
		}while(opt==1);
		
		
	}
	
	
	
}
