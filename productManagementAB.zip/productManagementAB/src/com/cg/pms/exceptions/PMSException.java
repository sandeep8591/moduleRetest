package com.cg.pms.exceptions;

public class PMSException extends Exception {

	public PMSException(String message) {
		super(message);
	}
}
